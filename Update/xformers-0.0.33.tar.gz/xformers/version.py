# noqa: C801
__version__ = "0.0.33+aa7bc366.d20260104"
